import Hero from '@/components/Hero'
import Categories from '@/components/Categories'
import FeaturedProducts from '@/components/FeaturedProducts'
import ImageGallery from '@/components/ImageGallery'
import About from '@/components/About'
import Process from '@/components/Process'
import WhyChooseUs from '@/components/WhyChooseUs'
import Testimonials from '@/components/Testimonials'
import Contact from '@/components/Contact'
import Footer from '@/components/Footer'
import Navigation from '@/components/Navigation'

export default function Home() {
  // Featured images from different categories for homepage gallery
  const featuredImages = [
    '/assets/Sportswear.jpg',
    '/assets/Winter Wear.jpg',
    '/assets/Hoodie.jpg',
    '/assets/Leisure Wear.jpg',
    '/assets/GYM Wear.jpg',
    '/assets/Shirts.jpg',
    '/assets/Sportswear (2).jpg',
    '/assets/Winter Wear (2).jpg',
    '/assets/Hoodie (2).jpg',
    '/assets/Leisure Wear (2).jpg',
    '/assets/Sportswear (3).jpg',
    '/assets/Winter Wear (3).jpg',
    '/assets/Hoodie (3).jpg',
    '/assets/Leisure Wear (3).jpg',
    '/assets/GYM Wear (2).jpg',
    '/assets/Shits.jpg',
    '/assets/Sportswear (4).jpg',
    '/assets/Winter Wear (4).jpg',
    '/assets/Hoodie (4).jpg',
    '/assets/Leisure Wear (4).jpg',
  ]

  return (
    <main className="min-h-screen overflow-x-hidden">
      <Navigation />
      <Hero />
      <div className="relative">
        {/* Decorative gradient background elements */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-primary-200/20 dark:bg-primary-900/10 rounded-full blur-3xl -z-10" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-200/20 dark:bg-blue-900/10 rounded-full blur-3xl -z-10" />
      </div>
      <Categories />
      <FeaturedProducts />
      <ImageGallery 
        images={featuredImages}
        title="Our Premium Collection"
        subtitle="Discover quality craftsmanship across all our product categories"
      />
      <About />
      <Process />
      <WhyChooseUs />
      <Testimonials />
      <Contact />
      <Footer />
    </main>
  )
}

