// Utility to get images by category from assets folder

export interface CategoryImage {
  src: string
  alt: string
}

export const getCategoryImages = (categoryName: string): CategoryImage[] => {
  const images: CategoryImage[] = []
  
  // Map category names to their image patterns
  const categoryMap: Record<string, string[]> = {
    'sportswear': [
      '/assets/Sportswear.jpg',
      '/assets/Sportswear (2).jpg',
      '/assets/Sportswear (3).jpg',
      '/assets/Sportswear (4).jpg',
      '/assets/Sportswear (5).jpg',
      '/assets/Sportswear (6).jpg',
      '/assets/Sportswear (7).jpg',
      '/assets/Sportswear (8).jpg',
      '/assets/Sportswear (9).jpg',
      '/assets/Sportswear (10).jpg',
      '/assets/Sportswear (11).jpg',
      '/assets/Sportswear (12).jpg',
      '/assets/Sportswear (13).jpg',
      '/assets/Sportswear (14).jpg',
      '/assets/Sportswear (15).jpg',
      '/assets/Sportswear (16).jpg',
      '/assets/Sportswear (17).jpg',
      '/assets/Sportswear (18).jpg',
      '/assets/Sportswear (19).jpg',
    ],
    'winter-wear': [
      '/assets/Winter Wear.jpg',
      '/assets/Winter Wear1.jpg',
      '/assets/Winter Wear2.jpg',
      '/assets/Winter Wear2 (2).jpg',
      '/assets/Winter Wear4.jpg',
      '/assets/Winter Wear (2).jpg',
      '/assets/Winter Wear (3).jpg',
      '/assets/Winter Wear (4).jpg',
      '/assets/Winter Wear (5).jpg',
      '/assets/Winter Wear (6).jpg',
      '/assets/Winter Wear (7).jpg',
      '/assets/Winter Wear (8).jpg',
      '/assets/Winter Wear (9).jpg',
      '/assets/Winter Wear (10).jpg',
      '/assets/Winter Wear (11).jpg',
      '/assets/Winter Wear (12).jpg',
    ],
    'summer-wear': [
      '/assets/Shirts.jpg',
      '/assets/Shirt.jpg',
      '/assets/Shits.jpg',
      '/assets/Shits (2).jpg',
      '/assets/Shits (3).jpg',
      '/assets/Shits (4).jpg',
      '/assets/Shits (5).jpg',
      '/assets/Shits (6).jpg',
      '/assets/Shits (7).jpg',
      '/assets/Shits (8).jpg',
      '/assets/Shits (9).jpg',
      '/assets/Shits (10).jpg',
      '/assets/Shits (11).jpg',
      '/assets/Shits (12).jpg',
      '/assets/Shits (13).jpg',
      '/assets/Shits (14).jpg',
      '/assets/Shits (15).jpg',
    ],
    'street-wear': [
      '/assets/Hoodie.jpg',
      '/assets/Hoodie (2).jpg',
      '/assets/Hoodie (3).jpg',
      '/assets/Hoodie (4).jpg',
      '/assets/Hoodie (5).jpg',
      '/assets/Hoodie (6).jpg',
      '/assets/Hoodie (7).jpg',
      '/assets/Hoodie (8).jpg',
      '/assets/hoodie (9).jpg',
    ],
    'leisure-wear': [
      '/assets/Leisure Wear.jpg',
      '/assets/Leisure Wear (2).jpg',
      '/assets/Leisure Wear (3).jpg',
      '/assets/Leisure Wear (4).jpg',
      '/assets/Leisure Wear (5).jpg',
      '/assets/Leisure Wear (6).jpg',
      '/assets/Leisure Wear (7).jpg',
      '/assets/Leisure Wear (8).jpg',
      '/assets/Leisure Wear (9).jpg',
      '/assets/Leisure Wear (10).jpg',
      '/assets/Leisure Wear (11).jpg',
      '/assets/Leisure Wear (12).jpg',
    ],
    'gym-wear': [
      '/assets/GYM Wear.jpg',
      '/assets/GYM Wear (2).jpg',
      '/assets/GYM Wear (3).jpg',
      '/assets/GYM Wear (4).jpg',
      '/assets/GYM Wear (5).jpg',
      '/assets/GYM Wear (6).jpg',
    ],
    'rain-wear': [
      '/assets/Sportswear (2).jpg',
      '/assets/Sportswear (3).jpg',
      '/assets/Sportswear (4).jpg',
    ],
  }

  const imagePaths = categoryMap[categoryName.toLowerCase()] || []
  
  return imagePaths.map((src, index) => ({
    src,
    alt: `${categoryName} Product ${index + 1}`,
  }))
}

export const getCategoryInfo = (slug: string) => {
  const categories: Record<string, { name: string; description: string; mainImage: string }> = {
    'sportswear': {
      name: 'Sportswear',
      description: 'High-performance athletic apparel designed for professional and recreational sports. Our sportswear collection combines functionality with style, using premium fabrics that offer breathability, flexibility, and durability.',
      mainImage: '/assets/Sportswear.jpg',
    },
    'winter-wear': {
      name: 'Winter Wear',
      description: 'Warm and durable winter clothing designed to keep you comfortable in cold weather conditions. Our winter wear collection features insulated materials and stylish designs for all ages.',
      mainImage: '/assets/Winter Wear.jpg',
    },
    'summer-wear': {
      name: 'Summer Wear',
      description: 'Lightweight and breathable summer clothing perfect for hot weather. Our summer collection includes comfortable shirts and casual wear made from premium cotton and moisture-wicking fabrics.',
      mainImage: '/assets/Shirts.jpg',
    },
    'street-wear': {
      name: 'Street Wear',
      description: 'Trendy urban fashion for the modern lifestyle. Our street wear collection features hoodies, casual tops, and contemporary designs that blend comfort with street style aesthetics.',
      mainImage: '/assets/Hoodie.jpg',
    },
    'leisure-wear': {
      name: 'Leisure Wear',
      description: 'Comfortable casual wear for everyday activities. Perfect for lounging, casual outings, or relaxed social gatherings. Our leisure wear prioritizes comfort without compromising on style.',
      mainImage: '/assets/Leisure Wear.jpg',
    },
    'gym-wear': {
      name: 'Gym Wear',
      description: 'Flexible and durable workout apparel for fitness enthusiasts. Designed for performance, our gym wear offers maximum mobility, moisture management, and support during intense training sessions.',
      mainImage: '/assets/GYM Wear.jpg',
    },
    'rain-wear': {
      name: 'Rain Wear',
      description: 'Waterproof and weather-resistant protective clothing. Our rain wear collection keeps you dry and comfortable during wet weather conditions, featuring advanced waterproofing technology.',
      mainImage: '/assets/Sportswear (2).jpg',
    },
  }

  return categories[slug.toLowerCase()] || {
    name: 'Category',
    description: 'Premium quality garments',
    mainImage: '/assets/Sportswear.jpg',
  }
}

